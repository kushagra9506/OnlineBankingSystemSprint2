import { Component, OnInit } from '@angular/core';

@Component({
  selector: '<router-outlet></router-outlet>',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.less']
})
export class RegisterUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
